#' @importFrom utils globalVariables
globalVariables(c("income_score", "education_score", "occupation_score", "total_score", "lower", "upper"))
